`ifndef __PIPELINE_TYPES_SV
`define __PIPELINE_TYPES_SV

`ifdef VERILATOR
`include "include/common.sv"
`endif

// 流水线寄存器类型定义包
// 使用 packed struct 确保硬件综合时紧密打包，提高面积效率
// unpacked struct 在 Verilator 中不被支持，且硬件实现效率较低
package pipeline_pkg;
	import common::*;

	// IF/ID 流水线寄存器：锁存取指阶段的结果
	// valid 位标识该锁存器中是否包含有效指令
	// pc 和 instr 在同一周期被捕获，确保指令与地址的时空一致性
	typedef struct packed {
		logic valid;  // IF 阶段是否成功取到指令（受 data_ok 控制）
		u64   pc;     // 指令的程序计数器值（64位地址）
		u32   instr;  // 32位 RISC-V 指令码
	} reg_if_id_t;

	// ID/EX 流水线寄存器：锁存译码阶段的结果
	// 包含完整的指令解码信息和操作数，供执行阶段直接使用
	// src1/src2 已经经过 WB 阶段旁路处理，解决了最近的数据冒险
	typedef struct packed {
		logic valid;     // ID 阶段输入指令是否有效
		u64   pc;        // 指令 PC（用于异常处理和调试）
		u32   instr;     // 原始指令码（Difftest 需要）
		u5    rd;        // 目标寄存器编号（写回阶段使用）
		u5    rs1;       // 源寄存器1编号（转发检测用）
		u5    rs2;       // 源寄存器2编号（转发检测用）
		u64   src1;      // 操作数1（已应用WB旁路）
		u64   src2;      // 操作数2（已应用WB旁路）
		u64   imm;       // 立即数（已符号扩展）
		logic wen;       // 是否写寄存器（控制写回阶段）
		logic use_imm;   // 是否使用立即数作为操作数2
		logic is_word;   // 是否为32位字操作（需符号扩展）
		logic is_sub;    // 是否为减法（add/sub共用funct3编码）
		u3    funct3;    // 功能选择字段（决定ALU操作类型）
		logic is_trap;   // 是否为停机指令（CUSTOM-3）
	} reg_id_ex_t;

	// EX/MEM 流水线寄存器：锁存执行阶段的结果
	// ALU 计算已完成，result 包含最终运算结果
	// 此阶段为转发提供最近的数据源（距离为1的转发）
	typedef struct packed {
		logic valid;    // EX 阶段输入是否有效
		u64   pc;       // 指令 PC（Difftest 和异常用）
		u32   instr;    // 原始指令码
		u5    rd;       // 目标寄存器编号（转发检测和写回用）
		u64   result;   // ALU 运算结果（已处理字运算扩展）
		logic wen;      // 是否写寄存器
		logic is_trap;  // 是否为停机指令
	} reg_ex_mem_t;

	// MEM/WB 流水线寄存器：与 EX/MEM 结构相同
	// 本设计中 MEM 阶段无实际访存操作，纯直通
	// 但保留独立类型便于未来扩展（如支持 load/store）
	typedef reg_ex_mem_t reg_mem_wb_t;

endpackage

`endif
