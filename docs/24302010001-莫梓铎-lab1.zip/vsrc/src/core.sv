`ifndef __CORE_SV
`define __CORE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`include "src/regfile.sv"
`include "src/fetch.sv"
`include "src/decode.sv"
`include "src/execute.sv"
`endif

// CPU 顶层模块：五级流水线控制器
// 负责实例化各功能模块，管理流水线寄存器推进，处理全局控制信号
// 协调各阶段间的时序关系，确保指令在流水线中正确流动
module core
	import common::*;
	import pipeline_pkg::*;
(
	input  logic       clk,     // 主时钟信号（所有模块共享同一时钟域）
	input  logic       reset,   // 异步复位信号
	output ibus_req_t  ireq,    // 指令总线请求（送往 RAM）
	input  ibus_resp_t iresp,   // 指令总线响应（来自 RAM）
	output dbus_req_t  dreq,    // 数据总线请求（lab1 未使用，恒为 0）
	input  dbus_resp_t dresp,   // 数据总线响应（lab1 未使用）
	input  logic       trint, swint, exint  // 中断信号（lab1 未使用）
);

	// ========== 流水线寄存器：连接各级模块的数据通道 ==========
	// 这些寄存器在每个时钟周期锁存前级模块的输出
	// 形成流水线的"阶段隔离"，允许各阶段并行处理不同指令
	reg_if_id_t  if_id;   // IF/ID：锁存取指结果（指令 + PC）
	reg_id_ex_t  id_ex;   // ID/EX：锁存译码结果（操作数 + 控制信号）
	reg_ex_mem_t ex_mem;  // EX/MEM：锁存执行结果（ALU 运算结果）
	reg_mem_wb_t mem_wb;  // MEM/WB：锁存访存结果（本设计中为直通）

	// ========== 全局状态寄存器：跟踪 CPU 运行状态 ==========
	// cycle_cnt 和 instr_cnt 用于性能统计和调试
	// halt_flag 实现精确的停机控制，确保指令完整执行
	u64   cycle_cnt;   // 总时钟周期计数（包括停机后周期）
	u64   instr_cnt;   // 已提交指令计数（仅有效指令）
	logic halt_flag;   // 停机标志：置位后冻结整个流水线

	// ========== 全局停机检测：防止流水线冲突 ==========
	// 组合逻辑：扫描所有流水线阶段，检测是否出现停机指令
	// halt_flag 本身也参与检测，形成锁存机制防止重复触发
	// 这确保一旦进入停机状态，流水线永久冻结
	logic halt_seen;
	assign halt_seen = (if_id.valid  && if_id.instr[6:0] == 7'b1101011)  // IF 阶段检测
	                 | (id_ex.valid  && id_ex.is_trap)                   // ID 阶段检测
	                 | (ex_mem.valid && ex_mem.is_trap)                  // EX 阶段检测
	                 | (mem_wb.valid && mem_wb.is_trap)                  // MEM 阶段检测
	                 | halt_flag;                                        // 已停机状态

	// ========== 数据总线接口：lab1 中未使用的信号 ==========
	// DBus 在当前设计中恒为空操作，为未来支持 load/store 指令预留
	assign dreq.valid  = 1'b0;    // 永不发起数据访问请求
	assign dreq.addr   = '0;      // 地址无关
	assign dreq.size   = MSIZE8;  // 传输大小字段（未使用）
	assign dreq.strobe = '0;      // 字节使能掩码（未使用）
	assign dreq.data   = '0;      // 写入数据（未使用）

	// ========== 取指阶段实例化 ==========
	// fetch 模块管理 PC 和 IF/ID 寄存器，处理指令获取
	// halt_seen 信号防止在停机状态下继续发出总线请求
	fetch u_fetch(
		.clk       (clk),
		.reset     (reset),
		.iresp     (iresp),       // 总线响应输入
		.halt_seen (halt_seen),   // 停机控制输入
		.ireq      (ireq),        // 总线请求输出
		.if_id     (if_id)        // IF/ID 寄存器输出
	);

	// ========== 译码阶段信号连接 ==========
	// decode 模块为纯组合逻辑，接收 IF/ID 输入并产生 ID/EX 输出
	// rs1_addr/rs2_addr 输出给寄存器堆，id_ex_next 由时序逻辑采样
	u5  rs1_addr, rs2_addr;      // 寄存器读取地址
	u64 gpr_rd1, gpr_rd2;        // 寄存器读取结果
	reg_id_ex_t id_ex_next;      // decode 模块的组合输出

	decode u_decode(
		.if_id      (if_id),       // IF/ID 流水线寄存器输入
		.mem_wb     (mem_wb),      // MEM/WB 输入（用于 WB 旁路）
		.gpr_rd1    (gpr_rd1),     // 寄存器读端口1输出
		.gpr_rd2    (gpr_rd2),     // 寄存器读端口2输出
		.rs1_addr   (rs1_addr),    // rs1 地址输出
		.rs2_addr   (rs2_addr),    // rs2 地址输出
		.id_ex_next (id_ex_next)   // ID/EX 组合输出
	);

	// ========== 执行阶段实例化 ==========
	// execute 模块为纯组合逻辑，实现转发和 ALU 运算
	// ex_mem_next 输出由时序逻辑在 posedge 采样到 ex_mem 寄存器
	reg_ex_mem_t ex_mem_next;    // execute 模块的组合输出

	execute u_execute(
		.id_ex       (id_ex),        // ID/EX 流水线寄存器输入
		.ex_mem      (ex_mem),       // EX/MEM 输入（一级转发源）
		.mem_wb      (mem_wb),       // MEM/WB 输入（二级转发源）
		.ex_mem_next (ex_mem_next)   // EX/MEM 组合输出
	);

	// ========== 寄存器堆实例化 ==========
	// regfile 模块管理 32 个通用寄存器，支持双读单写
	// 写入操作来自 MEM/WB 阶段，读取操作服务于 decode 阶段
	logic  rf_wen;     // 寄存器写使能
	u5     rf_waddr;   // 写入目标地址
	u64    rf_wdata;   // 写入数据
	u64    gpr_next [31:0];  // Difftest 旁路输出

	// 写回控制信号生成：组合逻辑决定何时写寄存器
	// halt_flag 检查防止停机后意外写入
	assign rf_wen   = mem_wb.valid && mem_wb.wen && (mem_wb.rd != 5'd0) && !halt_flag;
	assign rf_waddr = mem_wb.rd;    // 写入目标寄存器
	assign rf_wdata = mem_wb.result; // 写入数据（ALU 结果）

	regfile u_regfile(
		.clk      (clk),
		.reset    (reset),
		.wen      (rf_wen),      // 写使能
		.waddr    (rf_waddr),    // 写地址
		.wdata    (rf_wdata),    // 写数据
		.raddr1   (rs1_addr),    // 读地址1（来自 decode）
		.rdata1   (gpr_rd1),     // 读数据1输出
		.raddr2   (rs2_addr),    // 读地址2（来自 decode）
		.rdata2   (gpr_rd2),     // 读数据2输出
		.gpr_next (gpr_next)     // Difftest 旁路输出
	);

	// ========== 流水线推进控制：统一时钟域的时序协调 ==========
	// 所有流水线寄存器在同一 always_ff 块中更新
	// 确保各阶段推进的原子性，避免竞争条件
	// reset 优先级最高，建立可靠的初始状态
	always_ff @(posedge clk) begin
		if (reset) begin
			// 复位时清空所有流水线寄存器和状态计数器
			// valid 位清零使流水线处于空闲状态
			id_ex     <= '0;         // ID/EX 无效
			ex_mem    <= '0;         // EX/MEM 无效
			mem_wb    <= '0;         // MEM/WB 无效
			cycle_cnt <= '0;         // 周期计数清零
			instr_cnt <= '0;         // 指令计数清零
			halt_flag <= 1'b0;       // 清除停机标志
		end else begin
			// 正常运行时更新周期计数（即使停机后也继续计数）
			cycle_cnt <= cycle_cnt + 64'd1;

			// 若未停机，则推进流水线各阶段
			if (!halt_flag) begin
				// 写回阶段簿记：更新指令计数和停机标志
				// instr_cnt 在指令提交时递增，用于性能评估
				if (mem_wb.valid)
					instr_cnt <= instr_cnt + 64'd1;
				// halt_flag 在停机指令提交时置位，永久冻结流水线
				if (mem_wb.valid && mem_wb.is_trap)
					halt_flag <= 1'b1;

				// 流水线寄存器逐级推进（从后向前更新避免数据相关）
				// MEM/WB <- EX/MEM：访存阶段直通（lab1 无实际访存）
				mem_wb <= ex_mem;
				// EX/MEM <- execute 模块输出：锁存 ALU 运算结果
				ex_mem <= ex_mem_next;
				// ID/EX <- decode 模块输出：锁存译码结果
				id_ex <= id_ex_next;
				// IF/ID 由 fetch 模块内部管理（在 fetch.sv 中更新）
			end
			// halt_flag 为高时不执行任何流水线推进操作
		end
	end

	// ========== Difftest 接口：指令级仿真验证 ==========
	// 所有 Difftest 模块在时钟上升沿采样，与参考模型对比
	// 接口位于 WB 阶段，确保比较的是已完全执行的指令状态
`ifdef VERILATOR
	// 指令提交接口：每条指令在 WB 阶段提交给 Difftest
	// valid 信号确保仅在有效指令提交时触发对比
	DifftestInstrCommit DifftestInstrCommit(
		.clock              (clk),
		.coreid             (0),                    // 单核系统标识
		.index              (0),                    // 单发射标识
		.valid              (mem_wb.valid && !halt_flag),  // 仅在非停机时提交
		.pc                 (mem_wb.pc),            // 指令地址
		.instr              (mem_wb.instr),         // 原始指令码
		.skip               (0),                    // 分支预测相关（未使用）
		.isRVC              (0),                    // 压缩指令标志（未使用）
		.scFailed           (0),                    // 原子操作失败标志（未使用）
		.wen                (mem_wb.wen && (mem_wb.rd != 5'd0)),  // 写寄存器使能
		.wdest              ({3'b0, mem_wb.rd}),    // 目标寄存器编号（8位）
		.wdata              (mem_wb.result)         // 写入数据
	);

	// 寄存器状态接口：提供所有通用寄存器的当前值
	// 使用 gpr_next 组合旁路确保 Difftest 看到写入后的状态
	DifftestArchIntRegState DifftestArchIntRegState (
		.clock              (clk),
		.coreid             (0),
		.gpr_0              (0),                    // x0 恒为 0
		.gpr_1              (gpr_next[1]),          // 各寄存器当前状态
		.gpr_2              (gpr_next[2]),
		.gpr_3              (gpr_next[3]),
		.gpr_4              (gpr_next[4]),
		.gpr_5              (gpr_next[5]),
		.gpr_6              (gpr_next[6]),
		.gpr_7              (gpr_next[7]),
		.gpr_8              (gpr_next[8]),
		.gpr_9              (gpr_next[9]),
		.gpr_10             (gpr_next[10]),
		.gpr_11             (gpr_next[11]),
		.gpr_12             (gpr_next[12]),
		.gpr_13             (gpr_next[13]),
		.gpr_14             (gpr_next[14]),
		.gpr_15             (gpr_next[15]),
		.gpr_16             (gpr_next[16]),
		.gpr_17             (gpr_next[17]),
		.gpr_18             (gpr_next[18]),
		.gpr_19             (gpr_next[19]),
		.gpr_20             (gpr_next[20]),
		.gpr_21             (gpr_next[21]),
		.gpr_22             (gpr_next[22]),
		.gpr_23             (gpr_next[23]),
		.gpr_24             (gpr_next[24]),
		.gpr_25             (gpr_next[25]),
		.gpr_26             (gpr_next[26]),
		.gpr_27             (gpr_next[27]),
		.gpr_28             (gpr_next[28]),
		.gpr_29             (gpr_next[29]),
		.gpr_30             (gpr_next[30]),
		.gpr_31             (gpr_next[31])
	);

	// 异常事件接口：报告停机指令的执行
	// 在 halt 指令提交时触发一次，传递退出码
	DifftestTrapEvent DifftestTrapEvent(
		.clock              (clk),
		.coreid             (0),
		.valid              (mem_wb.valid && mem_wb.is_trap && !halt_flag),  // 精确触发条件
		.code               (gpr_next[10][2:0]),    // 从 x10 提取 3 位退出码
		.pc                 (mem_wb.pc),             // 停机指令地址
		.cycleCnt           (cycle_cnt),             // 总周期数
		.instrCnt           (instr_cnt)              // 已执行指令数
	);

	// CSR 状态接口：当前设计未实现 CSR，全部置零
	// 为未来扩展保留接口
	DifftestCSRState DifftestCSRState(
		.clock              (clk),
		.coreid             (0),
		.priviledgeMode     (3),                     // 机器模式
		.mstatus            (0),
		.sstatus            (0),
		.mepc               (0),
		.sepc               (0),
		.mtval              (0),
		.stval              (0),
		.mtvec              (0),
		.stvec              (0),
		.mcause             (0),
		.scause             (0),
		.satp               (0),
		.mip                (0),
		.mie                (0),
		.mscratch           (0),
		.sscratch           (0),
		.mideleg            (0),
		.medeleg            (0)
	);
`endif

endmodule

`endif
