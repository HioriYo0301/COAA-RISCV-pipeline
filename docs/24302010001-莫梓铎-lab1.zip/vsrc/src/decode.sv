`ifndef __DECODE_SV
`define __DECODE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

// 译码阶段（ID）：纯组合逻辑模块，负责指令解码和操作数准备
// 从 IF/ID 锁存器获取指令，生成控制信号并读取寄存器操作数
// 实现 WB 阶段旁路以解决最近的数据冒险（距离为3的转发）
module decode
	import common::*;
	import pipeline_pkg::*;
(
	input  reg_if_id_t  if_id,      // IF/ID 输入：待译码的指令
	input  reg_mem_wb_t mem_wb,     // MEM/WB 输入：用于 WB 旁路检测
	input  u64          gpr_rd1,    // 寄存器读端口1的输出值
	input  u64          gpr_rd2,    // 寄存器读端口2的输出值
	output u5           rs1_addr,   // 输出：rs1 寄存器地址（发往寄存器堆）
	output u5           rs2_addr,   // 输出：rs2 寄存器地址（发往寄存器堆）
	output reg_id_ex_t  id_ex_next  // ID/EX 输出：译码结果（组合逻辑）
);

	// 指令字段提取：组合逻辑解包 32 位指令
	// 这些 assign 语句在每个时钟周期即时响应 if_id.instr 的变化
	logic [6:0] opcode;  // 操作码：决定指令类型
	u5          rd;      // 目标寄存器
	u5          rs1;     // 源寄存器1
	u5          rs2;     // 源寄存器2
	u3          funct3;  // 功能字段：细化 ALU 操作

	assign opcode = if_id.instr[6:0];     // [6:0] 位域提取
	assign rd     = if_id.instr[11:7];    // [11:7] 目标寄存器编号
	assign rs1    = if_id.instr[19:15];   // [19:15] 源寄存器1编号
	assign rs2    = if_id.instr[24:20];   // [24:20] 源寄存器2编号
	assign funct3 = if_id.instr[14:12];   // [14:12] ALU 功能选择

	// 寄存器地址输出：直接转发给寄存器堆的读端口
	// 这是纯组合连接，无时序延迟
	assign rs1_addr = rs1;  // 告诉寄存器堆要读取哪个寄存器
	assign rs2_addr = rs2;

	// 控制信号生成：组合逻辑译码器
	// 根据 opcode 确定指令的行为特征
	// 使用 always_comb 确保所有信号在同一 delta cycle 内稳定
	logic wen;       // 是否写寄存器（控制 WB 阶段）
	logic use_imm;   // 是否使用立即数（区分 RR vs RI 指令）
	logic is_word;   // 是否为 32 位字操作（需符号扩展）
	logic is_sub;    // 是否为减法（add/sub 共享 funct3）
	logic is_trap;   // 是否为停机指令

	always_comb begin
		// 默认值：大多数指令不写寄存器
		wen     = 1'b0;
		use_imm = 1'b0;
		is_word = 1'b0;
		is_sub  = 1'b0;
		is_trap = 1'b0;

		// 指令类型译码：case 语句实现硬件多路选择器
		case (opcode)
			7'b0010011: begin  // OP-IMM 类型（addi, xori, ori, andi）
				wen     = 1'b1;    // 立即数运算结果需写回寄存器
				use_imm = 1'b1;    // 使用立即数作为第二个操作数
			end
			7'b0110011: begin  // OP 类型（add, sub, and, or, xor）
				wen    = 1'b1;     // 寄存器-寄存器运算结果需写回
				is_sub = if_id.instr[30];  // [30] 位区分 add(0) 和 sub(1)
			end
			7'b0011011: begin  // OP-IMM-32 类型（addiw）
				wen     = 1'b1;
				use_imm = 1'b1;
				is_word = 1'b1;    // 32 位运算，结果需符号扩展到 64 位
			end
			7'b0111011: begin  // OP-32 类型（addw, subw）
				wen     = 1'b1;
				is_word = 1'b1;
				is_sub  = if_id.instr[30];  // 同样用 [30] 位区分
			end
			7'b1101011: begin  // CUSTOM-3 停机指令
				is_trap = 1'b1;    // 标记为特殊控制指令
			end
			default: ;  // 其他 opcode 保持默认值（无效指令）
		endcase
	end

	// 立即数生成：I 型指令的符号扩展
	// 组合逻辑：根据 opcode 决定立即数格式并扩展符号位
	u64 imm;
	always_comb begin
		case (opcode)
			7'b0010011, 7'b0011011:  // OP-IMM 和 OP-IMM-32
				// I 型立即数：[31:20] 位域，符号扩展到 64 位
				// {{52{bit31}}, [31:20]} 实现符号位复制
				imm = {{52{if_id.instr[31]}}, if_id.instr[31:20]};
			default:
				imm = 64'd0;  // 非立即数指令，imm 无意义
		endcase
	end

	// 寄存器读取 + WB 旁路：解决距离为3的数据冒险
	// 当前指令在 ID 阶段读取寄存器，而前一条指令在 WB 阶段才写入
	// 必须通过组合逻辑旁路将最新结果直接传递，避免读到旧值
	// 这是典型的"写后读"(RAW) 数据冒险解决方案
	u64 src1, src2;
	always_comb begin
		// src1 操作数的来源选择（优先级从高到低）：
		// 1. x0 硬连线为 0（硬件优化：节省寄存器资源）
		// 2. WB 旁路：mem_wb 阶段正在写入的目标寄存器匹配 rs1
		// 3. 寄存器堆读取：使用当前 gpr 中的值
		if (rs1 == 5'd0)
			src1 = 64'd0;  // x0 永远为 0（RISC-V 架构规定）
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == rs1)
			src1 = mem_wb.result;  // 旁路最近的写入结果
		else
			src1 = gpr_rd1;  // 从寄存器堆读取

		// src2 同理处理
		if (rs2 == 5'd0)
			src2 = 64'd0;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == rs2)
			src2 = mem_wb.result;
		else
			src2 = gpr_rd2;
	end

	// 打包输出：将所有译码结果组合成 ID/EX 流水线寄存器格式
	// 这些 assign 在同一组合逻辑块中完成，确保输出一致性
	assign id_ex_next.valid   = if_id.valid;      // 继承 IF/ID 的有效性
	assign id_ex_next.pc      = if_id.pc;         // 传递指令地址
	assign id_ex_next.instr   = if_id.instr;      // 传递原始指令码
	assign id_ex_next.rd      = rd;               // 目标寄存器编号
	assign id_ex_next.rs1     = rs1;              // 源寄存器1（转发检测用）
	assign id_ex_next.rs2     = rs2;              // 源寄存器2（转发检测用）
	assign id_ex_next.src1    = src1;             // 操作数1（已旁路处理）
	assign id_ex_next.src2    = src2;             // 操作数2（已旁路处理）
	assign id_ex_next.imm     = imm;              // 立即数（已符号扩展）
	assign id_ex_next.wen     = wen;              // 写使能控制信号
	assign id_ex_next.use_imm = use_imm;          // 立即数使用标志
	assign id_ex_next.is_word = is_word;          // 字运算标志
	assign id_ex_next.is_sub  = is_sub;           // 减法标志
	assign id_ex_next.funct3  = funct3;           // ALU 功能选择
	assign id_ex_next.is_trap = is_trap;          // 停机指令标志

endmodule

`endif
