`ifndef __EXECUTE_SV
`define __EXECUTE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

// 执行阶段（EX）：纯组合逻辑模块，负责数据转发和 ALU 运算
// 实现两级转发：EX/MEM（距离1）和 MEM/WB（距离2）的前递路径
// 转发优先级：EX/MEM > MEM/WB > 寄存器堆读取（基于物理距离的延迟优化）
module execute
	import common::*;
	import pipeline_pkg::*;
(
	input  reg_id_ex_t  id_ex,    // ID/EX 输入：待执行的指令信息
	input  reg_ex_mem_t ex_mem,   // EX/MEM 输入：一级转发源
	input  reg_mem_wb_t mem_wb,   // MEM/WB 输入：二级转发源
	output reg_ex_mem_t ex_mem_next  // EX/MEM 输出：执行结果
);

	// 转发多路选择器：为 src1 操作数选择最新数据源
	// 优先级设计原理：EX/MEM 距离更近（延迟更小），优先级最高
	// 这是硬件层面的时间局部性优化：越近的数据越可能是最新值
	u64 fwd_src1;
	always_comb begin
		// 转发条件：上游阶段有效、写使能开启、目标寄存器匹配且非 x0
		// valid 检查确保转发源包含有效数据
		// rd != 0 避免与 x0 硬连线冲突
		if (ex_mem.valid && ex_mem.wen && ex_mem.rd != 5'd0 && ex_mem.rd == id_ex.rs1)
			fwd_src1 = ex_mem.result;  // EX/MEM 转发：距离为1的最近结果
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == id_ex.rs1)
			fwd_src1 = mem_wb.result;  // MEM/WB 转发：距离为2的次新结果
		else
			fwd_src1 = id_ex.src1;     // 默认：使用 ID 阶段读取的寄存器值
	end

	// src2 的转发逻辑与 src1 完全对称
	u64 fwd_src2;
	always_comb begin
		if (ex_mem.valid && ex_mem.wen && ex_mem.rd != 5'd0 && ex_mem.rd == id_ex.rs2)
			fwd_src2 = ex_mem.result;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == id_ex.rs2)
			fwd_src2 = mem_wb.result;
		else
			fwd_src2 = id_ex.src2;
	end

	// ALU 运算单元：组合逻辑实现多功能算术逻辑运算
	// 输入操作数已通过转发 MUX 选择最新值，确保计算正确性
	u64 alu_a, alu_b, alu_result, result;

	// 操作数选择：alu_a 始终为 fwd_src1，alu_b 根据指令类型选择
	assign alu_a = fwd_src1;  // 第一个操作数直接来自转发结果
	assign alu_b = id_ex.use_imm ? id_ex.imm : fwd_src2;  // 立即数 or 转发的 src2

	// ALU 核心运算逻辑：根据 funct3 和 is_sub 决定具体操作
	// 使用 case 语句实现硬件多路选择器，综合为门级电路
	always_comb begin
		case (id_ex.funct3)
			3'b000:  // ADD/SUB 功能
				// is_sub 标志区分加法(0)和减法(1)
				// 减法实现为 a + (~b + 1)，但此处直接使用减法运算符
				alu_result = id_ex.is_sub ? (alu_a - alu_b) : (alu_a + alu_b);
			3'b100:  // XOR 功能：按位异或
				alu_result = alu_a ^ alu_b;
			3'b110:  // OR 功能：按位或
				alu_result = alu_a | alu_b;
			3'b111:  // AND 功能：按位与
				alu_result = alu_a & alu_b;
			default: // 未定义操作码，返回 0（安全性设计）
				alu_result = 64'd0;
		endcase
	end

	// 字运算处理：32 位运算结果符号扩展到 64 位
	// is_word 标志指示是否为 RV64 的 32 位子集指令
	// 符号扩展：复制第 31 位到高位 32 位，保持数值语义
	assign result = id_ex.is_word ? {{32{alu_result[31]}}, alu_result[31:0]}  // 符号扩展
	                              : alu_result;                               // 64 位运算直接使用

	// 打包输出：构造 EX/MEM 流水线寄存器
	// 所有 assign 语句构成组合逻辑云，在同一 delta cycle 完成
	assign ex_mem_next.valid   = id_ex.valid;      // 继承指令有效性
	assign ex_mem_next.pc      = id_ex.pc;         // 传递 PC（异常处理用）
	assign ex_mem_next.instr   = id_ex.instr;      // 传递原始指令码
	assign ex_mem_next.rd      = id_ex.rd;         // 目标寄存器编号
	assign ex_mem_next.result  = result;           // ALU 运算结果
	assign ex_mem_next.wen     = id_ex.wen;        // 写使能控制
	assign ex_mem_next.is_trap = id_ex.is_trap;    // 停机指令标志

endmodule

`endif
