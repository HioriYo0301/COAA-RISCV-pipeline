`ifndef __FETCH_SV
`define __FETCH_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

// 取指阶段（IF）：负责程序计数器管理和指令获取
// 采用阻塞式取指策略：若总线未就绪则插入气泡，确保指令完整性
// PC 在每个周期递增4，除非遇到停机或总线未响应
module fetch
	import common::*;
	import pipeline_pkg::*;
(
	input  logic       clk,     // 主时钟信号（上升沿触发）
	input  logic       reset,   // 异步复位信号（高电平有效）
	input  ibus_resp_t iresp,   // 指令总线响应（来自 RAM）
	input  logic       halt_seen, // 全局停机检测信号（防止总线冲突）
	output ibus_req_t  ireq,    // 指令总线请求（发往 RAM）
	output reg_if_id_t if_id    // IF/ID 流水线寄存器输出
);

	// 程序计数器：指向当前要取的指令地址
	// 时序逻辑：仅在时钟上升沿更新，确保地址稳定性
	u64 pc;

	// 组合逻辑：生成总线请求信号
	// halt_seen 为高时禁止发出新请求，防止总线冲突
	// 这是硬件层面的互斥锁机制，避免多个模块同时访问总线
	assign ireq.valid = !halt_seen;  // 请求使能由停机状态控制
	assign ireq.addr  = pc;          // 请求地址始终为当前 PC

	// 时序逻辑：管理 PC 和 IF/ID 流水线寄存器
	// 使用非阻塞赋值确保所有信号在同一时钟边沿更新
	// reset 优先级最高，确保系统可靠初始化
	always_ff @(posedge clk) begin
		if (reset) begin
			// 复位时将 PC 初始化为标准入口地址
			// IF/ID 寄存器清零，标记为无效指令
			pc    <= PCINIT;  // RISC-V 标准入口：0x80000000
			if_id <= '0;      // 结构体清零，valid=0
		end else if (!halt_seen) begin
			// 正常运行状态下处理取指逻辑
			// 必须等待 iresp.data_ok 才能确认指令获取完成
			// 这体现了硬件握手协议的本质：生产者-消费者同步
			if (iresp.data_ok) begin
				// 总线响应就绪：捕获指令并推进 PC
				// valid 置1表示 IF/ID 中包含有效指令
				// PC 在指令被捕获后立即递增，为下一条指令做准备
				if_id.valid <= 1'b1;           // 标记指令有效
				if_id.pc    <= pc;             // 锁存当前 PC（指令地址）
				if_id.instr <= iresp.data;     // 锁存指令内容（32位）
				pc          <= pc + 64'd4;     // PC 前进到下一条指令
			end else begin
				// 总线未就绪：插入气泡（流水线停顿）
				// valid 清0使后续阶段识别为无效指令
				// PC 保持不变，下周期重试同一地址
				if_id.valid <= 1'b0;           // 插入气泡
			end
		end
		// halt_seen 为高时不执行任何操作，保持当前状态
	end

endmodule

`endif
