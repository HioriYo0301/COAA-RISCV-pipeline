`ifndef __REGFILE_SV
`define __REGFILE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

// 寄存器堆模块：32个64位通用寄存器，支持双端口读取和单端口写入
// 读取为组合逻辑（零延迟），写入为时序逻辑（时钟边沿触发）
// 实现 gpr_next 组合旁路，解决 Difftest 在写回周期读取寄存器状态的问题
module regfile
	import common::*;
	import pipeline_pkg::*;
(
	input  logic clk,    // 时钟信号（写入操作同步）
	input  logic reset,  // 异步复位信号
	// 写端口：来自 WB 阶段的写回请求
	input  logic wen,    // 写使能信号（高电平写入）
	input  u5    waddr,  // 写入目标寄存器地址
	input  u64   wdata,  // 写入数据
	// 读端口1：为 rs1 提供操作数（连接到 decode 模块）
	input  u5    raddr1, // 读取地址1
	output u64   rdata1, // 读取数据1
	// 读端口2：为 rs2 提供操作数（连接到 decode 模块）
	input  u5    raddr2, // 读取地址2
	output u64   rdata2, // 读取数据2
	// gpr_next：组合逻辑旁路，供 Difftest 读取下一周期的寄存器状态
	output u64   gpr_next [31:0]
);

	// 32个64位通用寄存器存储体
	// 时序逻辑：仅在时钟上升沿更新，确保写入操作的确定性
	// 复位时清零所有寄存器，建立确定的初始状态
	u64 gpr [31:0];

	// 组合逻辑读端口：即时响应地址输入，零延迟输出
	// 这是典型的双端口 SRAM 读取行为：多个读端口可并发工作
	// x0 寄存器硬连线为 0，这是 RISC-V 架构的核心特性
	// 硬连线实现节省了实际存储单元，减少硬件面积
	assign rdata1 = (raddr1 == 5'd0) ? 64'd0 : gpr[raddr1];  // 读端口1
	assign rdata2 = (raddr2 == 5'd0) ? 64'd0 : gpr[raddr2];  // 读端口2

	// gpr_next 组合旁路逻辑：为 Difftest 提供"视作已写入"的寄存器状态
	// 这解决了硬件时序与软件仿真之间的视角差异：
	// - 硬件中：写入在 posedge 执行，读取在同一个周期看到旧值
	// - Difftest 需要：在指令提交时看到写入后的结果
	// 通过组合逻辑提前计算下一状态，使 Difftest 读取到预期值
	always_comb begin
		for (int i = 0; i < 32; i++) begin
			if (i == 0)
				gpr_next[i] = 64'd0;  // x0 永远为 0
			else if (wen && waddr == i[4:0])
				// 如果当前周期有写入操作且地址匹配，则旁路新值
				// 这使 Difftest 看到"已经完成写入"的状态
				gpr_next[i] = wdata;
			else
				// 否则保持当前存储体的值
				gpr_next[i] = gpr[i];
		end
	end

	// 时序逻辑写端口：在时钟上升沿执行寄存器更新
	// 使用非阻塞赋值确保写入操作与时钟同步
	// 对 x0 的写入被显式忽略，强化架构约束
	always_ff @(posedge clk) begin
		if (reset) begin
			// 复位时将所有寄存器初始化为 0
			// 这建立了系统的确定性初始状态，便于调试和验证
			for (int i = 0; i < 32; i++)
				gpr[i] <= 64'd0;
		end else begin
			// 正常运行时处理写入请求
			// 写使能且目标非 x0 时执行写入
			// x0 的写入被硬件忽略，体现 RISC-V 的零寄存器语义
			if (wen && waddr != 5'd0)
				gpr[waddr] <= wdata;  // 在下一个时钟周期生效
		end
	end

endmodule

`endif
