`ifndef __PIPELINE_TYPES_SV
`define __PIPELINE_TYPES_SV

`ifdef VERILATOR
`include "include/common.sv"
`endif

package pipeline_pkg;
	import common::*;

	// IF/ID
	typedef struct packed {
		logic valid;
		u64   pc;
		u32   instr;
	} reg_if_id_t;

	// ID/EX
	typedef struct packed {
		logic   valid;
		u64     pc;
		u32     instr;
		u5      rd;
		u5      rs1;
		u5      rs2;
		u64     src1;
		u64     src2;
		u64     imm;

		logic   wen;
		logic   use_imm;
		logic   is_word;
		logic   is_sub;
		u3      funct3;
		logic   is_trap;

		// lab2: memory/lui control
		logic   is_lui;
		logic   is_load;
		logic   is_store;
		msize_t mem_size;
		logic   load_unsigned;
	} reg_id_ex_t;

	// EX/MEM
	typedef struct packed {
		logic   valid;
		u64     pc;
		u32     instr;
		u5      rd;
		u64     result;
		logic   wen;
		logic   is_trap;

		// lab2: memory access info
		logic   is_load;
		logic   is_store;
		msize_t mem_size;
		logic   load_unsigned;
		u64     mem_addr;
		u64     store_data;
	} reg_ex_mem_t;

	// MEM/WB
	typedef struct packed {
		logic valid;
		u64   pc;
		u32   instr;
		u5    rd;
		u64   result;
		logic wen;
		logic is_trap;
	} reg_mem_wb_t;

endpackage

`endif
