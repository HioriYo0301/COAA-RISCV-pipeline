`ifndef __EXECUTE_SV
`define __EXECUTE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

module execute
	import common::*;
	import pipeline_pkg::*;
(
	input  reg_id_ex_t  id_ex,
	input  reg_ex_mem_t ex_mem,
	input  reg_mem_wb_t mem_wb,
	output reg_ex_mem_t ex_mem_next
);

	u64 fwd_src1;
	always_comb begin
		if (ex_mem.valid && ex_mem.wen && ex_mem.rd != 5'd0 && ex_mem.rd == id_ex.rs1)
			fwd_src1 = ex_mem.result;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == id_ex.rs1)
			fwd_src1 = mem_wb.result;
		else
			fwd_src1 = id_ex.src1;
	end

	u64 fwd_src2;
	always_comb begin
		if (ex_mem.valid && ex_mem.wen && ex_mem.rd != 5'd0 && ex_mem.rd == id_ex.rs2)
			fwd_src2 = ex_mem.result;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == id_ex.rs2)
			fwd_src2 = mem_wb.result;
		else
			fwd_src2 = id_ex.src2;
	end

	u64 alu_a, alu_b, alu_result, result;

	assign alu_a = fwd_src1;
	assign alu_b = id_ex.use_imm ? id_ex.imm : fwd_src2;

	always_comb begin
		case (id_ex.funct3)
			3'b000: alu_result = id_ex.is_sub ? (alu_a - alu_b) : (alu_a + alu_b);
			3'b100: alu_result = alu_a ^ alu_b;
			3'b110: alu_result = alu_a | alu_b;
			3'b111: alu_result = alu_a & alu_b;
			default: alu_result = 64'd0;
		endcase
	end

	always_comb begin
		if (id_ex.is_lui)
			result = id_ex.imm;
		else if (id_ex.is_word)
			result = {{32{alu_result[31]}}, alu_result[31:0]};
		else
			result = alu_result;
	end

	assign ex_mem_next.valid         = id_ex.valid;
	assign ex_mem_next.pc            = id_ex.pc;
	assign ex_mem_next.instr         = id_ex.instr;
	assign ex_mem_next.rd            = id_ex.rd;
	assign ex_mem_next.result        = result;
	assign ex_mem_next.wen           = id_ex.wen;
	assign ex_mem_next.is_trap       = id_ex.is_trap;

	assign ex_mem_next.is_load       = id_ex.is_load;
	assign ex_mem_next.is_store      = id_ex.is_store;
	assign ex_mem_next.mem_size      = id_ex.mem_size;
	assign ex_mem_next.load_unsigned = id_ex.load_unsigned;
	assign ex_mem_next.mem_addr      = fwd_src1 + id_ex.imm;
	assign ex_mem_next.store_data    = fwd_src2;

endmodule

`endif
