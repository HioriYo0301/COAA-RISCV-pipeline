`ifndef __DECODE_SV
`define __DECODE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`endif

module decode
	import common::*;
	import pipeline_pkg::*;
(
	input  reg_if_id_t  if_id,
	input  reg_mem_wb_t mem_wb,
	input  u64          gpr_rd1,
	input  u64          gpr_rd2,
	output u5           rs1_addr,
	output u5           rs2_addr,
	output reg_id_ex_t  id_ex_next
);

	logic [6:0] opcode;
	u5          rd;
	u5          rs1;
	u5          rs2;
	u3          funct3;

	assign opcode = if_id.instr[6:0];
	assign rd     = if_id.instr[11:7];
	assign rs1    = if_id.instr[19:15];
	assign rs2    = if_id.instr[24:20];
	assign funct3 = if_id.instr[14:12];

	assign rs1_addr = rs1;
	assign rs2_addr = rs2;

	logic wen;
	logic use_imm;
	logic is_word;
	logic is_sub;
	logic is_trap;
	logic is_lui;
	logic is_load;
	logic is_store;
	msize_t mem_size;
	logic load_unsigned;

	always_comb begin
		wen           = 1'b0;
		use_imm       = 1'b0;
		is_word       = 1'b0;
		is_sub        = 1'b0;
		is_trap       = 1'b0;
		is_lui        = 1'b0;
		is_load       = 1'b0;
		is_store      = 1'b0;
		mem_size      = MSIZE8;
		load_unsigned = 1'b0;

		case (opcode)
			7'b0010011: begin // OP-IMM
				wen     = 1'b1;
				use_imm = 1'b1;
			end
			7'b0110011: begin // OP
				wen    = 1'b1;
				is_sub = if_id.instr[30];
			end
			7'b0011011: begin // OP-IMM-32
				wen     = 1'b1;
				use_imm = 1'b1;
				is_word = 1'b1;
			end
			7'b0111011: begin // OP-32
				wen     = 1'b1;
				is_word = 1'b1;
				is_sub  = if_id.instr[30];
			end
			7'b0110111: begin // LUI
				wen     = 1'b1;
				use_imm = 1'b1;
				is_lui  = 1'b1;
			end
			7'b0000011: begin // LOAD
				wen      = 1'b1;
				use_imm  = 1'b1;
				is_load  = 1'b1;
				case (funct3)
					3'b000: begin mem_size = MSIZE1; load_unsigned = 1'b0; end // lb
					3'b001: begin mem_size = MSIZE2; load_unsigned = 1'b0; end // lh
					3'b010: begin mem_size = MSIZE4; load_unsigned = 1'b0; end // lw
					3'b011: begin mem_size = MSIZE8; load_unsigned = 1'b0; end // ld
					3'b100: begin mem_size = MSIZE1; load_unsigned = 1'b1; end // lbu
					3'b101: begin mem_size = MSIZE2; load_unsigned = 1'b1; end // lhu
					3'b110: begin mem_size = MSIZE4; load_unsigned = 1'b1; end // lwu
					default: begin
						wen      = 1'b0;
						is_load  = 1'b0;
						mem_size = MSIZE8;
					end
				endcase
			end
			7'b0100011: begin // STORE
				wen      = 1'b0;
				use_imm  = 1'b1;
				is_store = 1'b1;
				case (funct3)
					3'b000: mem_size = MSIZE1; // sb
					3'b001: mem_size = MSIZE2; // sh
					3'b010: mem_size = MSIZE4; // sw
					3'b011: mem_size = MSIZE8; // sd
					default: begin
						is_store = 1'b0;
						mem_size = MSIZE8;
					end
				endcase
			end
			7'b1101011: begin // trap
				is_trap = 1'b1;
			end
			default: ;
		endcase
	end

	u64 imm;
	always_comb begin
		case (opcode)
			7'b0010011, 7'b0011011, 7'b0000011: // I-type
				imm = {{52{if_id.instr[31]}}, if_id.instr[31:20]};
			7'b0100011: // S-type
				imm = {{52{if_id.instr[31]}}, if_id.instr[31:25], if_id.instr[11:7]};
			7'b0110111: // U-type (lui)
				imm = {{32{if_id.instr[31]}}, if_id.instr[31:12], 12'b0};
			default:
				imm = 64'd0;
		endcase
	end

	u64 src1, src2;
	always_comb begin
		if (rs1 == 5'd0)
			src1 = 64'd0;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == rs1)
			src1 = mem_wb.result;
		else
			src1 = gpr_rd1;

		if (rs2 == 5'd0)
			src2 = 64'd0;
		else if (mem_wb.valid && mem_wb.wen && mem_wb.rd != 5'd0 && mem_wb.rd == rs2)
			src2 = mem_wb.result;
		else
			src2 = gpr_rd2;
	end

	assign id_ex_next.valid         = if_id.valid;
	assign id_ex_next.pc            = if_id.pc;
	assign id_ex_next.instr         = if_id.instr;
	assign id_ex_next.rd            = rd;
	assign id_ex_next.rs1           = rs1;
	assign id_ex_next.rs2           = rs2;
	assign id_ex_next.src1          = src1;
	assign id_ex_next.src2          = src2;
	assign id_ex_next.imm           = imm;
	assign id_ex_next.wen           = wen;
	assign id_ex_next.use_imm       = use_imm;
	assign id_ex_next.is_word       = is_word;
	assign id_ex_next.is_sub        = is_sub;
	assign id_ex_next.funct3        = funct3;
	assign id_ex_next.is_trap       = is_trap;
	assign id_ex_next.is_lui        = is_lui;
	assign id_ex_next.is_load       = is_load;
	assign id_ex_next.is_store      = is_store;
	assign id_ex_next.mem_size      = mem_size;
	assign id_ex_next.load_unsigned = load_unsigned;

endmodule

`endif
