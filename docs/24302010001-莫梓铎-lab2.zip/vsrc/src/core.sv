`ifndef __CORE_SV
`define __CORE_SV

`ifdef VERILATOR
`include "include/common.sv"
`include "include/pipeline_types.sv"
`include "src/regfile.sv"
`include "src/fetch.sv"
`include "src/decode.sv"
`include "src/execute.sv"
`endif

module core
	import common::*;
	import pipeline_pkg::*;
(
	input  logic       clk,
	input  logic       reset,
	output ibus_req_t  ireq,
	input  ibus_resp_t iresp,
	output dbus_req_t  dreq,
	input  dbus_resp_t dresp,
	input  logic       trint, swint, exint
);

	reg_if_id_t  if_id;
	reg_id_ex_t  id_ex;
	reg_ex_mem_t ex_mem;
	reg_mem_wb_t mem_wb;

	u64   cycle_cnt;
	u64   instr_cnt;
	logic halt_flag;

	logic halt_seen;
	logic pipe_hold;
	logic fetch_block;
	logic mem_is_access;
	logic mem_done;
	assign halt_seen = (if_id.valid  && if_id.instr[6:0] == 7'b1101011)
	                 | (id_ex.valid  && id_ex.is_trap)
	                 | (ex_mem.valid && ex_mem.is_trap)
	                 | (mem_wb.valid && mem_wb.is_trap)
	                 | halt_flag;
	assign fetch_block = halt_seen | mem_is_access;

	u3 mem_off;
	u64 load_shifted;
	u64 load_result;
	logic [7:0] store_strobe;
	u64 store_data_aligned;
	reg_mem_wb_t mem_wb_next;

	assign mem_off      = ex_mem.mem_addr[2:0];
	assign load_shifted = dresp.data >> ({61'd0, mem_off} << 3);

	always_comb begin
		store_strobe = 8'b0;
		case (ex_mem.mem_size)
			MSIZE1: store_strobe = 8'b0000_0001 << mem_off;
			MSIZE2: store_strobe = 8'b0000_0011 << mem_off;
			MSIZE4: store_strobe = 8'b0000_1111 << mem_off;
			MSIZE8: store_strobe = 8'b1111_1111;
			default: store_strobe = 8'b0;
		endcase
	end

	assign store_data_aligned = ex_mem.store_data << ({61'd0, mem_off} << 3);

	always_comb begin
		case (ex_mem.mem_size)
			MSIZE1: load_result = ex_mem.load_unsigned ? {56'd0, load_shifted[7:0]} : {{56{load_shifted[7]}}, load_shifted[7:0]};
			MSIZE2: load_result = ex_mem.load_unsigned ? {48'd0, load_shifted[15:0]} : {{48{load_shifted[15]}}, load_shifted[15:0]};
			MSIZE4: load_result = ex_mem.load_unsigned ? {32'd0, load_shifted[31:0]} : {{32{load_shifted[31]}}, load_shifted[31:0]};
			MSIZE8: load_result = load_shifted;
			default: load_result = 64'd0;
		endcase
	end

	assign mem_is_access = ex_mem.valid && (ex_mem.is_load || ex_mem.is_store) && !halt_flag;
	assign mem_done      = !mem_is_access || dresp.data_ok;
	assign pipe_hold     = mem_is_access && !dresp.data_ok;

	always_comb begin
		mem_wb_next         = '0;
		mem_wb_next.valid   = ex_mem.valid;
		mem_wb_next.pc      = ex_mem.pc;
		mem_wb_next.instr   = ex_mem.instr;
		mem_wb_next.rd      = ex_mem.rd;
		mem_wb_next.wen     = ex_mem.wen;
		mem_wb_next.is_trap = ex_mem.is_trap;
		mem_wb_next.result  = ex_mem.result;

		if (ex_mem.is_load)
			mem_wb_next.result = load_result;
	end

	assign dreq.valid  = mem_is_access && !halt_flag;
	assign dreq.addr   = ex_mem.mem_addr;
	assign dreq.size   = ex_mem.mem_size;
	assign dreq.strobe = ex_mem.is_store ? store_strobe : 8'b0;
	assign dreq.data   = ex_mem.is_store ? store_data_aligned : 64'd0;

	fetch u_fetch(
		.clk       (clk),
		.reset     (reset),
		.iresp     (iresp),
		.halt_seen (fetch_block),
		.ireq      (ireq),
		.if_id     (if_id)
	);

	u5  rs1_addr, rs2_addr;
	u64 gpr_rd1, gpr_rd2;
	reg_id_ex_t id_ex_next;

	decode u_decode(
		.if_id      (if_id),
		.mem_wb     (mem_wb),
		.gpr_rd1    (gpr_rd1),
		.gpr_rd2    (gpr_rd2),
		.rs1_addr   (rs1_addr),
		.rs2_addr   (rs2_addr),
		.id_ex_next (id_ex_next)
	);

	reg_ex_mem_t ex_mem_next;

	execute u_execute(
		.id_ex       (id_ex),
		.ex_mem      (ex_mem),
		.mem_wb      (mem_wb),
		.ex_mem_next (ex_mem_next)
	);

	logic  rf_wen;
	u5     rf_waddr;
	u64    rf_wdata;
	u64    gpr_next [31:0];

	assign rf_wen   = mem_wb.valid && mem_wb.wen && (mem_wb.rd != 5'd0) && !halt_flag;
	assign rf_waddr = mem_wb.rd;
	assign rf_wdata = mem_wb.result;

	regfile u_regfile(
		.clk      (clk),
		.reset    (reset),
		.wen      (rf_wen),
		.waddr    (rf_waddr),
		.wdata    (rf_wdata),
		.raddr1   (rs1_addr),
		.rdata1   (gpr_rd1),
		.raddr2   (rs2_addr),
		.rdata2   (gpr_rd2),
		.gpr_next (gpr_next)
	);

	always_ff @(posedge clk) begin
		if (reset) begin
			id_ex     <= '0;
			ex_mem    <= '0;
			mem_wb    <= '0;
			cycle_cnt <= '0;
			instr_cnt <= '0;
			halt_flag <= 1'b0;
		end else begin
			cycle_cnt <= cycle_cnt + 64'd1;

			if (!halt_flag) begin
				if (mem_wb.valid)
					instr_cnt <= instr_cnt + 64'd1;
				if (mem_wb.valid && mem_wb.is_trap)
					halt_flag <= 1'b1;

				if (mem_done) begin
					mem_wb <= mem_wb_next;
					ex_mem <= ex_mem_next;
					if (mem_is_access)
						id_ex <= '0;
					else
						id_ex <= id_ex_next;
				end else begin
					mem_wb <= '0;
					ex_mem <= ex_mem;
					id_ex  <= id_ex;
				end
			end
		end
	end

`ifdef VERILATOR
	DifftestInstrCommit DifftestInstrCommit(
		.clock              (clk),
		.coreid             (0),
		.index              (0),
		.valid              (mem_wb.valid && !halt_flag),
		.pc                 (mem_wb.pc),
		.instr              (mem_wb.instr),
		.skip               (0),
		.isRVC              (0),
		.scFailed           (0),
		.wen                (mem_wb.wen && (mem_wb.rd != 5'd0)),
		.wdest              ({3'b0, mem_wb.rd}),
		.wdata              (mem_wb.result)
	);

	DifftestArchIntRegState DifftestArchIntRegState (
		.clock              (clk),
		.coreid             (0),
		.gpr_0              (0),
		.gpr_1              (gpr_next[1]),
		.gpr_2              (gpr_next[2]),
		.gpr_3              (gpr_next[3]),
		.gpr_4              (gpr_next[4]),
		.gpr_5              (gpr_next[5]),
		.gpr_6              (gpr_next[6]),
		.gpr_7              (gpr_next[7]),
		.gpr_8              (gpr_next[8]),
		.gpr_9              (gpr_next[9]),
		.gpr_10             (gpr_next[10]),
		.gpr_11             (gpr_next[11]),
		.gpr_12             (gpr_next[12]),
		.gpr_13             (gpr_next[13]),
		.gpr_14             (gpr_next[14]),
		.gpr_15             (gpr_next[15]),
		.gpr_16             (gpr_next[16]),
		.gpr_17             (gpr_next[17]),
		.gpr_18             (gpr_next[18]),
		.gpr_19             (gpr_next[19]),
		.gpr_20             (gpr_next[20]),
		.gpr_21             (gpr_next[21]),
		.gpr_22             (gpr_next[22]),
		.gpr_23             (gpr_next[23]),
		.gpr_24             (gpr_next[24]),
		.gpr_25             (gpr_next[25]),
		.gpr_26             (gpr_next[26]),
		.gpr_27             (gpr_next[27]),
		.gpr_28             (gpr_next[28]),
		.gpr_29             (gpr_next[29]),
		.gpr_30             (gpr_next[30]),
		.gpr_31             (gpr_next[31])
	);

	DifftestTrapEvent DifftestTrapEvent(
		.clock              (clk),
		.coreid             (0),
		.valid              (mem_wb.valid && mem_wb.is_trap && !halt_flag),
		.code               (gpr_next[10][2:0]),
		.pc                 (mem_wb.pc),
		.cycleCnt           (cycle_cnt),
		.instrCnt           (instr_cnt)
	);

	DifftestCSRState DifftestCSRState(
		.clock              (clk),
		.coreid             (0),
		.priviledgeMode     (3),
		.mstatus            (0),
		.sstatus            (0),
		.mepc               (0),
		.sepc               (0),
		.mtval              (0),
		.stval              (0),
		.mtvec              (0),
		.stvec              (0),
		.mcause             (0),
		.scause             (0),
		.satp               (0),
		.mip                (0),
		.mie                (0),
		.mscratch           (0),
		.sscratch           (0),
		.mideleg            (0),
		.medeleg            (0)
	);
`endif

endmodule

`endif
